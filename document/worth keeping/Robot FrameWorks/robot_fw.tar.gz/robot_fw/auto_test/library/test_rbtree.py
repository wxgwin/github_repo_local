import os

def test_rbtree():
	return os.system('./test.sh')
